import nodemailer from 'nodemailer'
import https from 'https'
import dns from 'dns'

dns.setDefaultResultOrder('ipv4first')

export type WelcomeMailResult = {
  delivered: boolean
  provider: string
  note: string
  subject: string
  message: string
  to: string
}

function buildWelcomeContent(name: string, email: string) {
  const subject = 'Welcome to EventDazzle — your account is ready'
  const message = `Hi ${name},

Welcome to EventDazzle!

Your account has been created successfully with this email: ${email}

You can now:
• Search concerts, comedy, sports and festivals near you
• Book Front / Middle / Back zone tickets
• Create and share your own events after login

Thanks for joining us.
— Team EventDazzle`

  const html = `
    <div style="font-family:Segoe UI,Arial,sans-serif;line-height:1.6;color:#111;max-width:560px;margin:0 auto;padding:24px">
      <h2 style="margin:0 0 12px;color:#E11D48">Welcome to EventDazzle</h2>
      <p>Hi ${name},</p>
      <p>Your account has been created successfully with this email: <strong>${email}</strong></p>
      <p>Thanks for joining us.<br/>— Team EventDazzle</p>
    </div>
  `

  return { subject, message, html }
}

function buildOtpContent(name: string, email: string, otp: string) {
  const subject = `${otp} is your EventDazzle login code`
  const message = `Hi ${name},

Your one-time login code for EventDazzle is: ${otp}

This code expires in 10 minutes. Do not share it with anyone.

If you did not request this, ignore this email.

— Team EventDazzle`

  const html = `
    <div style="font-family:Segoe UI,Arial,sans-serif;line-height:1.6;color:#111;max-width:560px;margin:0 auto;padding:24px">
      <h2 style="margin:0 0 12px;color:#E11D48">EventDazzle login code</h2>
      <p>Hi ${name},</p>
      <p>Your one-time login code is:</p>
      <p style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#E11D48">${otp}</p>
      <p>This code expires in <strong>10 minutes</strong>.</p>
      <p>— Team EventDazzle</p>
    </div>
  `

  return { subject, message, html }
}

function buildLoginAlertContent(name: string, email: string) {
  const when = new Date().toLocaleString('en-IN', { dateStyle: 'full', timeStyle: 'short' })
  const subject = 'New login to EventDazzle'
  const message = `Hi ${name},

Your EventDazzle account was just logged in using this email: ${email}

Time: ${when}

If this was you, no action is needed.

If you did not log in, secure your email account immediately.

— Team EventDazzle`

  const html = `
    <div style="font-family:Segoe UI,Arial,sans-serif;line-height:1.6;color:#111;max-width:560px;margin:0 auto;padding:24px">
      <h2 style="margin:0 0 12px;color:#E11D48">New login detected</h2>
      <p>Hi ${name},</p>
      <p>Your EventDazzle account was logged in using <strong>${email}</strong></p>
      <p>Time: ${when}</p>
      <p>— Team EventDazzle</p>
    </div>
  `

  return { subject, message, html }
}

async function sendWithSmtpOnce(
  to: string,
  subject: string,
  message: string,
  html: string,
  host: string,
  port: number
) {
  const user = process.env.SMTP_USER?.trim()
  const pass = process.env.SMTP_PASS?.replace(/\s/g, '')
  if (!user || !pass) return null

  const from = process.env.EMAIL_FROM?.trim() || `EventDazzle <${user}>`

  const transporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
    tls: { rejectUnauthorized: false },
    connectionTimeout: 6000,
    greetingTimeout: 6000,
    socketTimeout: 6000,
    family: 4,
  } as nodemailer.TransportOptions)

  await transporter.sendMail({ from, to, subject, text: message, html, replyTo: user })
  return { provider: 'smtp', note: `sent via ${host}:${port}` }
}

async function sendWithSmtp(to: string, subject: string, message: string, html: string) {
  const attempts = [
    { host: process.env.SMTP_HOST?.trim() || 'smtp.gmail.com', port: Number(process.env.SMTP_PORT || 465) },
    { host: 'smtp.gmail.com', port: 465 },
    { host: 'smtp.gmail.com', port: 587 },
  ]

  let lastError: Error | null = null
  for (const attempt of attempts) {
    try {
      const result = await sendWithSmtpOnce(to, subject, message, html, attempt.host, attempt.port)
      if (result) return result
    } catch (err) {
      lastError = err instanceof Error ? err : new Error('SMTP failed')
    }
  }

  if (lastError) throw lastError
  return null
}

async function sendWithResend(to: string, subject: string, message: string, html: string) {
  const key = process.env.RESEND_API_KEY?.trim()
  if (!key) return null

  const from = process.env.EMAIL_FROM?.trim() || 'EventDazzle <onboarding@resend.dev>'
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [to], subject, text: message, html }),
  })

  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as { message?: string }).message || `Resend failed (${res.status})`)
  return { provider: 'resend', note: 'sent via Resend' }
}

function postFormSubmit(email: string, body: Record<string, string>) {
  const payload = JSON.stringify(body)
  const url = `https://formsubmit.co/ajax/${encodeURIComponent(email)}`

  return new Promise<{ ok: boolean; status: number; text: string }>((resolve, reject) => {
    const req = https.request(
      url,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
        rejectUnauthorized: false,
        family: 4,
        timeout: 15000,
      },
      (res) => {
        let data = ''
        res.on('data', (chunk) => {
          data += chunk
        })
        res.on('end', () => {
          resolve({ ok: (res.statusCode || 500) < 400, status: res.statusCode || 500, text: data })
        })
      }
    )
    req.on('error', reject)
    req.on('timeout', () => {
      req.destroy()
      reject(new Error('FormSubmit timed out'))
    })
    req.write(payload)
    req.end()
  })
}

async function sendWithFormSubmit(to: string, name: string, subject: string, message: string) {
  const result = await postFormSubmit(to, {
    name,
    email: to,
    _subject: subject,
    _template: 'table',
    _captcha: 'false',
    message,
  })
  if (!result.ok) throw new Error(`FormSubmit status ${result.status}`)
  return { provider: 'formsubmit', note: 'sent via FormSubmit' }
}

async function sendEmail(
  to: string,
  subject: string,
  message: string,
  html: string,
  name: string
): Promise<WelcomeMailResult> {
  const errors: string[] = []

  try {
    const smtp = await sendWithSmtp(to, subject, message, html)
    if (smtp) return { delivered: true, provider: smtp.provider, note: smtp.note, subject, message, to }
  } catch (err) {
    errors.push(`SMTP: ${err instanceof Error ? err.message : 'failed'}`)
  }

  try {
    const resend = await sendWithResend(to, subject, message, html)
    if (resend) return { delivered: true, provider: resend.provider, note: resend.note, subject, message, to }
  } catch (err) {
    errors.push(`Resend: ${err instanceof Error ? err.message : 'failed'}`)
  }

  try {
    const form = await sendWithFormSubmit(to, name, subject, message)
    return { delivered: true, provider: form.provider, note: form.note, subject, message, to }
  } catch (err) {
    errors.push(`FormSubmit: ${err instanceof Error ? err.message : 'failed'}`)
  }

  return {
    delivered: false,
    provider: 'none',
    note: errors.join(' | ') || 'No email provider configured',
    subject,
    message,
    to,
  }
}

export async function sendWelcomeEmail(name: string, email: string) {
  const { subject, message, html } = buildWelcomeContent(name, email)
  return sendEmail(email, subject, message, html, name)
}

export async function sendOtpEmail(name: string, email: string, otp: string) {
  const { subject, message, html } = buildOtpContent(name, email, otp)
  return sendEmail(email, subject, message, html, name)
}

export async function sendLoginAlertEmail(name: string, email: string) {
  const { subject, message, html } = buildLoginAlertContent(name, email)
  return sendEmail(email, subject, message, html, name)
}
