'use client'

import { useEffect, useState } from 'react'

type NearbyPlace = {
  name: string
  type: 'metro' | 'restaurant' | 'cafe' | 'shopping'
  distanceMeters: number
  address?: string
}

type NearbyData = {
  venue: string
  lat: number
  lng: number
  metro: NearbyPlace[]
  outlets: NearbyPlace[]
  source: string
}

const TYPE_LABEL: Record<NearbyPlace['type'], string> = {
  metro: 'Metro',
  restaurant: 'Restaurant',
  cafe: 'Café',
  shopping: 'Shopping',
}

function formatDistance(meters: number) {
  if (meters < 1000) return `${meters} m`
  return `${(meters / 1000).toFixed(1)} km`
}

export default function EventNearby({ eventId }: { eventId: string }) {
  const [data, setData] = useState<NearbyData | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    setError('')
    fetch(`/api/events/${encodeURIComponent(eventId)}/nearby`)
      .then(async (res) => {
        const json = await res.json()
        if (!res.ok) throw new Error(json.error || 'Could not load nearby places')
        setData(json)
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : 'Could not load nearby places')
      })
      .finally(() => setLoading(false))
  }, [eventId])

  if (loading) {
    return (
      <div className="rounded-2xl border border-surface-line bg-grey-50 p-5">
        <p className="text-sm text-grey-500">Loading real nearby metro & outlets from OpenStreetMap...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
        <p className="text-sm text-amber-800">{error}</p>
      </div>
    )
  }

  if (!data) return null

  return (
    <div className="space-y-5 rounded-2xl border border-surface-line p-5">
      <div>
        <h2 className="text-lg font-semibold">Nearby access & outlets</h2>
        <p className="mt-1 text-sm text-grey-500">
          Real data from {data.source} · geocoded: {data.venue}
        </p>
        <a
          href={`https://www.openstreetmap.org/?mlat=${data.lat}&mlon=${data.lng}#map=16/${data.lat}/${data.lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-block text-sm font-medium text-primary-500 hover:underline"
        >
          View on map →
        </a>
      </div>

      {data.metro.length > 0 ? (
        <div>
          <h3 className="mb-2 text-sm font-semibold uppercase tracking-wide text-grey-500">
            Nearest metro stations
          </h3>
          <ul className="space-y-2">
            {data.metro.map((place) => (
              <li
                key={`metro-${place.name}`}
                className="flex items-start justify-between gap-3 rounded-xl bg-primary-50/60 px-3 py-2 text-sm"
              >
                <div>
                  <p className="font-medium">{place.name}</p>
                  {place.address ? <p className="text-xs text-grey-500">{place.address}</p> : null}
                </div>
                <span className="shrink-0 text-xs font-semibold text-primary-600">
                  {formatDistance(place.distanceMeters)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="text-sm text-grey-500">No metro stations found within 1.5 km on OpenStreetMap.</p>
      )}

      {data.outlets.length > 0 ? (
        <div>
          <h3 className="mb-2 text-sm font-semibold uppercase tracking-wide text-grey-500">
            Nearby restaurants & outlets
          </h3>
          <ul className="space-y-2">
            {data.outlets.map((place) => (
              <li
                key={`${place.type}-${place.name}`}
                className="flex items-start justify-between gap-3 rounded-xl bg-grey-50 px-3 py-2 text-sm"
              >
                <div>
                  <p className="font-medium">{place.name}</p>
                  <p className="text-xs text-grey-500">{TYPE_LABEL[place.type]}</p>
                </div>
                <span className="shrink-0 text-xs font-semibold text-grey-600">
                  {formatDistance(place.distanceMeters)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="text-sm text-grey-500">No nearby outlets found within walking distance.</p>
      )}
    </div>
  )
}
