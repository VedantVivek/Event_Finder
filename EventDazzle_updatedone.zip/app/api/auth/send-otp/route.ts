import { NextRequest, NextResponse } from 'next/server'
import { sendOtpEmail } from '@/lib/mail'
import { createOtp } from '@/lib/otpStore'

export async function POST(req: NextRequest) {
  try {
    const { email, name } = (await req.json()) as { email?: string; name?: string }

    if (!email?.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    const trimmedEmail = email.trim().toLowerCase()
    const displayName = name?.trim() || trimmedEmail.split('@')[0] || 'User'
    const otp = createOtp(trimmedEmail, displayName)

    const result = await sendOtpEmail(displayName, trimmedEmail, otp)

    if (!result.delivered) {
      return NextResponse.json(
        { error: result.note || 'Could not send OTP email. Check SMTP settings in .env.local' },
        { status: 502 }
      )
    }

    return NextResponse.json({
      success: true,
      message: `OTP sent to ${trimmedEmail}. Check your inbox (and spam folder).`,
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to send OTP'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
