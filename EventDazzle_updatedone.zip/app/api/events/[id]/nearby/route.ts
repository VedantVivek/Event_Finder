import { NextResponse } from 'next/server'
import { getEventById } from '@/lib/eventsProvider'
import { fetchNearbyPlaces } from '@/lib/nearbyPlaces'

type RouteContext = {
  params: { id: string }
}

export async function GET(_request: Request, context: RouteContext) {
  try {
    const id = decodeURIComponent(context.params.id)
    const event = await getEventById(id)
    if (!event) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 })
    }

    const { coords, places } = await fetchNearbyPlaces({
      location: event.location,
      city: event.city,
    })

    const metro = places.filter((p) => p.type === 'metro').slice(0, 5)
    const outlets = places
      .filter((p) => p.type === 'restaurant' || p.type === 'cafe' || p.type === 'shopping')
      .slice(0, 8)

    return NextResponse.json({
      venue: coords.displayName,
      lat: coords.lat,
      lng: coords.lng,
      metro,
      outlets,
      source: 'OpenStreetMap',
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to load nearby places'
    return NextResponse.json({ error: message, metro: [], outlets: [] }, { status: 502 })
  }
}
